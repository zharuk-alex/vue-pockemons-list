# Pokemons list

-- Vite
-- Vue 3
-- Vuetify 3
-- Vuex
-- Vue-Router
-- Axios

[Demo](https://zharuk-alex.github.io/vue-pockemons-list/)

### Recommended IDE Setup

- [VS Code](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar)
